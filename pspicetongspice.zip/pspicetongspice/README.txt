1. you need to keep PspicetoNgspice.py and PSPICE .cir file in same folder 

2. To convert PSPICE to NGSPICE use following command,

python PspicetoNgspice.py filename.cir

3. Converted file will be with extension filename.cir.out

4. To execute file in ngspice use following command,

ngspice filename.cir


5. To include dummy sources print command is used at the end of netlist



